Open Process Export Converter

To use the converter:

1. Open index.html in Microsoft Edge, Google Chrome or Firefox.
2. Select your Open Process export file.
3. Follow the instructions shown in the converter.

No installation is required.

Files are processed locally within your web browser and are not
uploaded to GitHub or another server.

Users should handle exported data in accordance with their
organisation's information governance and data protection policies.